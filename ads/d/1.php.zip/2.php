<center>

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Text336-1 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-4266846516501036"
     data-ad-slot="8581595620"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
    


</center>