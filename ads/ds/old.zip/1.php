<style>
.example_responsive_1 { width: 320px; height: 100px; }
@media (min-width:330px) { .example_responsive_1 { width: 300px; height: 200px; } }
@media(min-width: 500px) { .example_responsive_1 { width: 468px; height: 60px; } }
@media(min-width: 800px) { .example_responsive_1 { width: 728px; height: 90px; } }
</style>

<center>

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- example_responsive_1 -->
<ins class="adsbygoogle example_responsive_1"
     style="display:inline-block"
     data-ad-client="ca-pub-4619674470520085"
     data-ad-slot="9550901059"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center> 