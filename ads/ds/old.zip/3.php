<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 336 bahu s -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-4619674470520085"
     data-ad-slot="4981100654"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
