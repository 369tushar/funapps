<!-- <div class='text inside-text'>Car donation is the practice of giving away no-longer-wanted automobiles or other vehicles to charitable organizations. In the United States, these donations can provide a tax benefit.
Some critics have claimed that car donations are essentially a tax shelter. However, non-profit organizations in the US have come to rely increasingly upon the revenue from car donations. This type of donation has become increasingly widespread; in 2000, 733,000 U.S. taxpayers reduced their taxes by $654 million.
Although advertised as an easy way to dispose of an old car, donors need to fulfill certain post-donation requirements to qualify for the tax deduction,[1] such as obtaining a written acknowledgment of the car's subsequent sale by the charity,[citation needed] and itemizing tax returns instead of taking the standard deduction.

For vehicles valued at less than $500, the deduction amount comes from the donor's own estimate of the car's value, even if the charity receives less money from its sale. Deductions greater than $500 are limited to the proceeds of selling the vehicle, usually at auction. The U.S Internal Revenue Service advises that starting in 2005:

The rules for determining the amount that a donor may deduct for a charitable contribution of a qualified vehicle, including an automobile, with a claimed value of more than $500 changed at the beginning of 2005 as a result of the American Jobs Creation Act of 2004. In general, that Act limits a donor’s deduction to the amount of the gross proceeds from the charity’s sale of the vehicle.

For vehicles valued at over $500, taxpayers are required to attach the charity's written acknowledgment to their tax return.[2]</div> -->

<style>
.example_responsive_1 { width: 320px; height: 100px; }
@media (min-width:330px) { .example_responsive_1 { width: 300px; height: 200px; } }
@media(min-width: 500px) { .example_responsive_1 { width: 468px; height: 60px; } }
@media(min-width: 800px) { .example_responsive_1 { width: 728px; height: 90px; } }
</style>



<center>
 
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle example_responsive_1"
     style="display:inline-block"
     data-ad-client="ca-pub-6578786145572606"
     data-ad-slot="8892814377"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center> 


<!--
 <a href="http://eng.369rocks.com/apps/431/app.php?fbid=10212307612279065">
          
       
         <img src="http://eng.369rocks.com/apps/431/img/10212307612279065.jpg" width="380px" height="280px" >  </a>

<br>
-->