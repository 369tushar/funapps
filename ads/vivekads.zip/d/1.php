<!-- Respons-share -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4266846516501036"
     data-ad-slot="1999751691"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>