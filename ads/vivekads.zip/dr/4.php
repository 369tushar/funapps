<?php
function isMobileDevice() {
    return preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);
}
if(isMobileDevice()){
    ?>
   



<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Hi_336_2 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-4266846516501036"
     data-ad-slot="7312269651"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
   
   
    <?php
}
else {
   ?>
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Respons-share -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4266846516501036"
     data-ad-slot="1999751691"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
    
    
    <?php
}
?>
