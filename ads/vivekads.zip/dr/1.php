                                                    <style>
                        .soulmate_728x90_header { width: 728px; height: 90px; }
                        @media(max-width: 1024px) { .soulmate_728x90_header { width: 468px; height: 60px;} }
                        @media(max-width: 768px) { .soulmate_728x90_header { width: 728px; height: 90px;} }
						@media(max-width: 640px) { .soulmate_728x90_header { width: 468px; height: 60px;} }
						@media(max-width: 480px) { .soulmate_728x90_header { width: 468px; height: 60px;} }
                        @media(max-width: 424px) { .soulmate_728x90_header { width: 300px; height: 250px;} }
						@media(max-width: 375px) { .soulmate_728x90_header { width: 300px; height: 250px;} }
                        
						
                        </style>
                        <div class="g_top_header">
                        
                            <script type="text/javascript">
                              var md = new MobileDetect(window.navigator.userAgent);
                              if(md.mobile() != null)
                              {
                                    //$('.g_top_header').hide();
                                    $('<ins>').attr({
                                    'class': "adsbygoogle soulmate_728x90_header",
                                    'style':"display:inline-block", 
                                    'data-ad-client':"ca-pub-4266846516501036",
                                    'data-ad-slot': "1999751691",
                                    
                                    'data-language': "en",
                                  }).appendTo('.g_top_header');
                                  (adsbygoogle = window.adsbygoogle || []).push({});
                                    //slot 7038733618
                                    
                              }
                              else
                              {
                                    $('<ins>').attr({
                                    'class': "adsbygoogle soulmate_728x90_header",
                                    'style':"display:inline-block", 
                                    'data-ad-client':"ca-pub-4266846516501036",
                                    'data-ad-slot': "1999751691",
                                    
                                    'data-language': "en",
                                  }).appendTo('.g_top_header');
                                  (adsbygoogle = window.adsbygoogle || []).push({});
                              }
                              
                              
                            </script>                            </div>